import { useParams } from 'react-router-dom';
import { useEffect, useState, useContext } from 'react';
import { LikeContext } from '../contexts/LikeContext';
import '../styles/EpisodeDetail.css';
import '../styles/CharacterList.css';

const EpisodeDetail = () => {
  const { id } = useParams();
  const [episode, setEpisode] = useState(null);
  const [characters, setCharacters] = useState([]);
  const { likes, toggleLike } = useContext(LikeContext);

  useEffect(() => {
    const fetchEpisode = async () => {
      const response = await fetch(`https://rickandmortyapi.com/api/episode/${id}`);
      const data = await response.json();
      setEpisode(data);

      const characterResponses = await Promise.all(
        data.characters.map((characterUrl) => fetch(characterUrl).then((res) => res.json()))
      );
      setCharacters(characterResponses);
    };

    fetchEpisode();
  }, [id]);

  if (!episode) {
    return <p className="loading">Cargando detalles del episodio...</p>;
  }

  return (
    <div className="episode-detail">
      <div className="episode-info">
        <h1 className="episode-title">{episode.name}</h1>
        <p><strong>Fecha de estreno:</strong> {episode.air_date}</p>
        <p><strong>Código del episodio:</strong> {episode.episode}</p>
      </div>

      <h3 className="character-title">Personajes:</h3>
      <div className="character-grid">
        {characters.map((character) => (
          <div key={character.id} className="character-card-new">
            <img src={character.image} alt={character.name} className="character-card-image" />
            <div className="character-card-info">
              <h3>{character.name}</h3>
              <p>🟢 {character.status} - {character.species}</p>
              <p><strong>Last known location:</strong><br />{character.location?.name}</p>
              <p><strong>First seen in:</strong><br />{character.origin?.name}</p>
              <button onClick={() => toggleLike(character.id)}>
                {likes[character.id] ? '❤️ Quitar Like' : '🤍 Dar Like'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EpisodeDetail;
