import '../styles/StaticPage.css';

const StaticPage = () => {
  return (
    <div className="static-page-container">
      <h1 className="static-title">Rick and Morty</h1>
      <div className="static-page-main">
        <div className="static-left">
          <img
            src="https://rickandmortyapi.com/api/character/avatar/1.jpeg"
            alt="Rick"
            className="main-image"
          />
        </div>

        <div className="vertical-divider"></div>

        <div className="static-right">
          <h2 className="static-subtitle">Novedades en el Multiverso</h2>
          
          <div className="gallery">
            <img src="https://rickandmortyapi.com/api/character/avatar/2.jpeg" alt="Morty" />
            <img src="https://rickandmortyapi.com/api/character/avatar/3.jpeg" alt="Summer" />
            <img src="https://rickandmortyapi.com/api/character/avatar/4.jpeg" alt="Beth" />
          </div>

          <p className="static-description">
            Disfruta de experiencias únicas en cada dimensión con Rick and Morty. 
            Viaja por el multiverso mientras Rick destruye reglas y Morty solo intenta sobrevivir. 
            Episodios llenos de caos, ciencia, aliens, y mucho sarcasmo.
          </p>
        </div>
      </div>
    </div>
  );
};

export default StaticPage;
