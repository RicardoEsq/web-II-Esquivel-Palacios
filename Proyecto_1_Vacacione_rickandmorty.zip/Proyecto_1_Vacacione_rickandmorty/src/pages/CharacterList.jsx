import { useContext } from 'react';
import { LikeContext } from '../contexts/LikeContext';
import '../styles/CharacterList.css';

const CharacterList = ({ characters }) => {
  const { likes, toggleLike } = useContext(LikeContext);

  return (
    <div className="character-grid">
      {characters.map((character) => (
        <div key={character.id} className="character-card-new">
          <img src={character.image} alt={character.name} className="character-card-image" />
          <div className="character-card-info">
            <h3>{character.name}</h3>
            <p>🟢 {character.status} - {character.species}</p>
            <p><strong>Last known location:</strong><br />{character.location?.name}</p>
            <p><strong>First seen in:</strong><br />{character.origin?.name}</p>
            <button onClick={() => toggleLike(character.id)}>
              {likes[character.id] ? '❤️ Quitar Like' : '🤍 Dar Like'}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default CharacterList;
