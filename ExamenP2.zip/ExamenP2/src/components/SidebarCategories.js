// src/components/SidebarCategories.js

export default function SidebarCategories({ categories, selected, onSelect }) {
  return (
    <aside className="sidebar">
      <h2>Categorías</h2>
      <ul>
        {categories.map((cat) => (
          <li
            key={cat.idCategory}
            className={selected === cat.strCategory ? 'active' : ''}
            onClick={() => onSelect(cat.strCategory)}
          >
            <img
              src={cat.strCategoryThumb}
              alt={cat.strCategory}
              style={{ width: '30px', height: '30px', borderRadius: '50%' }}
            />
            {cat.strCategory}
          </li>
        ))}
      </ul>
    </aside>
  );
}
