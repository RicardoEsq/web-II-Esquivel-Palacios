import { Link } from 'react-router-dom';

export default function RecipeCard({ meal }) {
  if (!meal) return null;

  return (
    <Link to={`/recipe/${meal.idMeal}`} className="card">
      <img src={meal.strMealThumb} alt={meal.strMeal} />
      <h3>{meal.strMeal}</h3>
    </Link>
  );
}
