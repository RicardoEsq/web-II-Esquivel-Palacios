export default function Hero() {
  return (
    <section className="hero">
      <div
        className="hero-img"
        style={{
          backgroundImage: `url(${process.env.PUBLIC_URL + '/comida.jpeg'})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          height: '100%',
          width: '100%',
          borderRadius: '1rem'
        }}
      />
      <div className="hero-text">
        <p className="subtext">🥄 New recipe for you to try out, let’s cook!</p>
        <h1>Chefs<br />Academy<br />Secrets</h1>
      </div>
    </section>
  );
}
