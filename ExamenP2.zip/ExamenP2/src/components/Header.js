export default function Header() {
  return (
    <header className="header">
      <h1>Chefs Academy Secrets</h1>
    </header>
  );
}
