import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { getMealDetails } from '../services/api';
import './RecipeDetail.css';

export default function RecipeDetail() {
  const { id } = useParams();
  const [meal, setMeal] = useState(null);
  const [ingredients, setIngredients] = useState([]);

  useEffect(() => {
    getMealDetails(id).then(data => {
      const mealData = data.meals[0];
      setMeal(mealData);

      // Recuperar ingredientes originales
      const ingList = [];
      for (let i = 1; i <= 20; i++) {
        const ing = mealData[`strIngredient${i}`];
        const meas = mealData[`strMeasure${i}`];
        if (ing && ing.trim()) {
          ingList.push(`${meas} ${ing}`);
        }
      }

      // Verificar si hay ingredientes eliminados guardados
      const eliminados = JSON.parse(localStorage.getItem(`eliminados-${id}`)) || [];
      const filtrados = ingList.filter(ing => !eliminados.includes(ing));

      setIngredients(filtrados);
    });
  }, [id]);

  const eliminarIngrediente = (index) => {
    const copia = [...ingredients];
    const eliminado = copia[index];
    copia.splice(index, 1);
    setIngredients(copia);

    // Guardar en localStorage
    const prev = JSON.parse(localStorage.getItem(`eliminados-${id}`)) || [];
    localStorage.setItem(`eliminados-${id}`, JSON.stringify([...prev, eliminado]));
  };

  const restaurarIngredientes = () => {
    localStorage.removeItem(`eliminados-${id}`);
    window.location.reload(); // Recarga para volver a cargar todo
  };

  if (!meal) return <p style={{ padding: '2rem' }}>Cargando receta...</p>;

  return (
    <div className="detail-page">
      <div className="recipe-header">
        <img src={meal.strMealThumb} alt={meal.strMeal} className="recipe-img" />
        <div className="recipe-info">
          <h1>{meal.strMeal}</h1>
          <p><strong>ID:</strong> {meal.idMeal}</p>
          <p><strong>Categoría:</strong> {meal.strCategory}</p>
          <p><strong>Origen:</strong> {meal.strArea}</p>
          {meal.strYoutube && (
            <a href={meal.strYoutube} target="_blank" rel="noopener noreferrer" className="youtube-btn">
              Ver video en YouTube 🎥
            </a>
          )}
          {meal.strSource && (
            <a href={meal.strSource} target="_blank" rel="noopener noreferrer" className="youtube-btn">
              Página web oficial 🌐
            </a>
          )}
        </div>
      </div>

      <div className="recipe-section">
        <h3>🧾 Instrucciones</h3>
        <p>{meal.strInstructions}</p>
      </div>

      <div className="recipe-section">
        <div className="ingredientes-titulo">
          <h3>🥄 Ingredientes</h3>
          <button className="restore-btn" onClick={restaurarIngredientes}>Restaurar todo</button>
        </div>
        <ul className="ingredients-list">
          {ingredients.map((item, index) => (
            <li key={index}>
              ✔️ {item}
              <button className="delete-btn" onClick={() => eliminarIngrediente(index)}>Eliminar</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
