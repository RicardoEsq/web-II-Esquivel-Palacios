import { useEffect, useState } from 'react';
import { getCategories, getMealsByCategory } from '../services/api';
import Hero from '../components/Hero';
import RecipeCard from '../components/RecipeCard';
import SidebarCategories from '../components/SidebarCategories';

export default function HomePage() {
  const [categories, setCategories] = useState([]);
  const [selected, setSelected] = useState('Seafood');
  const [meals, setMeals] = useState([]);
  const [sortOrder, setSortOrder] = useState('asc');

  useEffect(() => {
    getCategories().then(data => setCategories(data.categories));
  }, []);

  useEffect(() => {
    getMealsByCategory(selected).then(data => {
      const sorted = [...data.meals].sort((a, b) =>
        sortOrder === 'asc'
          ? a.strMeal.localeCompare(b.strMeal)
          : b.strMeal.localeCompare(a.strMeal)
      );
      setMeals(sorted);
    });
  }, [selected, sortOrder]);

  return (
    <div>
      <Hero />

      <div className="main-content">
        <SidebarCategories
          categories={categories}
          selected={selected}
          onSelect={setSelected}
        />

        <div className="recipes-section">
          <select
            className="sort-select"
            onChange={e => setSortOrder(e.target.value)}
            value={sortOrder}
          >
            <option value="asc">Ascendente</option>
            <option value="desc">Descendente</option>
          </select>

          <div className="grid">
            {meals.map(meal => (
              <RecipeCard key={meal.idMeal} meal={meal} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
